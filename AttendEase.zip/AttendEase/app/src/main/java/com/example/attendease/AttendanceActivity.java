package com.example.attendease;

import static com.example.attendease.LoginPage.username;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class AttendanceActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AttendanceAdapter adapter;
    private List<AttendanceRecord> attendanceList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_layout);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Setup RecyclerView
        recyclerView = findViewById(R.id.attendanceRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Initialize list and adapter
        attendanceList = new ArrayList<>();
        adapter = new AttendanceAdapter(attendanceList);
        recyclerView.setAdapter(adapter);

        // Fetch attendance data
        fetchAttendanceData();
    }

    private void fetchAttendanceData() {
        db.collection("Attendance").whereEqualTo("studentEmail", username.getText().toString())
            .get()
            .addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    attendanceList.clear();
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        // Assume each document has fields: name, date, status
                        AttendanceRecord record = document.toObject(AttendanceRecord.class);
                        record.setCourseId(document.getString("courseId"));
                        attendanceList.add(record);
                    }
                    adapter.notifyDataSetChanged();

                    // Show success message if data retrieved
                    if (attendanceList.isEmpty()) {
                        Toast.makeText(this, "No attendance records found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle errors
                    Toast.makeText(this, "Error fetching attendance: " + 
                        task.getException(), Toast.LENGTH_SHORT).show();
                }
            });
    }

    // Attendance Record Model
    public static class AttendanceRecord {
        private String courseId;
        private String professorId;
        private String professorName;

        private String studentEmail;
        private String studentId;
        private String studentName;
        private Timestamp timestamp;


        // Default constructor required for Firestore
        public AttendanceRecord() {}

        public AttendanceRecord(String name, String date, String status) {
            this.courseId = courseId;
            this.studentEmail = studentEmail;
            this.studentId = studentId;
            this.studentName = studentName;
            this.timestamp = timestamp;
        }

        //courseId
        //studentEmail
        //studentId
        //studentName
        //timestamp

        // Getters and Setters

        public String getCourseId() {
            return courseId;
        }

        public void setCourseId(String courseId) {
            this.courseId = courseId;
        }

        public String getProfessorId() {
            return professorId;
        }

        public void setProfessorId(String professorId) {
            this.professorId = professorId;
        }

        public String getProfessorName() {
            return professorName;
        }

        public void setProfessorName(String professorName) {
            this.professorName = professorName;
        }

        public String getStudentEmail() {
            return studentEmail;
        }

        public void setStudentEmail(String studentEmail) {
            this.studentEmail = studentEmail;
        }

        public String getStudentId() {
            return studentId;
        }

        public void setStudentId(String studentId) {
            this.studentId = studentId;
        }

        public String getStudentName() {
            return studentName;
        }

        public void setStudentName(String studentName) {
            this.studentName = studentName;
        }

        public Timestamp getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(Timestamp timestamp) {
            this.timestamp = timestamp;
        }
    }

    // RecyclerView Adapter
    public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder> {
        private List<AttendanceRecord> attendanceList;

        public AttendanceAdapter(List<AttendanceRecord> attendanceList) {
            this.attendanceList = attendanceList;
        }

        @NonNull
        @Override
        public AttendanceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_attendance_layout, parent, false);
            return new AttendanceViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull AttendanceViewHolder holder, int position) {
            AttendanceRecord record = attendanceList.get(position);
            holder.courseIdTextView.setText(record.getCourseId());
            holder.studentEmailTextView.setText(record.getStudentEmail());
            holder.studentIdTextView.setText(record.getStudentId());
            holder.studentNameTextView.setText(record.getStudentName());
            holder.timestampTextView.setText(record.getTimestamp().toDate().toString());
        }

        @Override
        public int getItemCount() {
            return attendanceList.size();
        }

        // ViewHolder Class
        public class AttendanceViewHolder extends RecyclerView.ViewHolder {
            //courseId
            //studentEmail
            //studentId
            //studentName
            //timestamp
            TextView courseIdTextView;
            TextView studentEmailTextView;
            TextView studentIdTextView;
            TextView studentNameTextView;
            TextView timestampTextView;


            public AttendanceViewHolder(@NonNull View itemView) {
                super(itemView);
                courseIdTextView = itemView.findViewById(R.id.courseIdTextView);
                studentEmailTextView = itemView.findViewById(R.id.studentEmailTextView);
                studentIdTextView = itemView.findViewById(R.id.studentIdTextView);
                studentNameTextView = itemView.findViewById(R.id.studentNameTextView);
                timestampTextView = itemView.findViewById(R.id.timestampTextView);

            }
        }
    }
}