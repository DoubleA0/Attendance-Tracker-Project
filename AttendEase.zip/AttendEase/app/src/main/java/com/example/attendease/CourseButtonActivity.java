package com.example.attendease;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CourseButtonActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private CourseButtonAdapter adapter;
    private List<Course> courseList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses_button_layout);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Setup RecyclerView
        recyclerView = findViewById(R.id.coursesButtonRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Initialize list and adapter
        courseList = new ArrayList<>();
        adapter = new CourseButtonAdapter(courseList);
        recyclerView.setAdapter(adapter);

        // Fetch course data
        fetchCourseData();
    }

    private void fetchCourseData() {
        // Use a Set to prevent duplicates
        Set<Course> uniqueCourses = new HashSet<>();

        // Fetch from UserCourses collection
        db.collection("UserCourses")
            .whereEqualTo("studentEmail", LoginPage.username.getText().toString())
            .get()
            .addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Course course = document.toObject(Course.class);
                        uniqueCourses.add(course);
                    }
                    
                    // Now search other collections
                    searchOtherCollections(uniqueCourses);
                } else {
                    Toast.makeText(this, "Error fetching UserCourses: " + 
                        task.getException(), Toast.LENGTH_SHORT).show();
                }
            });
    }

    private void searchOtherCollections(Set<Course> uniqueCourses) {
        // Get list of all collections
        db.collection("Courses")
            .get()
            .addOnCompleteListener(collectionsTask -> {
                if (collectionsTask.isSuccessful()) {
                    for (QueryDocumentSnapshot collection : collectionsTask.getResult()) {
                        String collectionName = collection.getId();
                        
                        // Query each collection for courses with matching student email
                        db.collection(collectionName)
                            .whereEqualTo("studentEmail", LoginPage.username.getText().toString())
                            .get()
                            .addOnCompleteListener(coursesTask -> {
                                if (coursesTask.isSuccessful()) {
                                    for (QueryDocumentSnapshot courseDoc : coursesTask.getResult()) {
                                        Course course = courseDoc.toObject(Course.class);
                                        uniqueCourses.add(course);
                                    }
                                    
                                    // Update list and adapter
                                    courseList.clear();
                                    courseList.addAll(uniqueCourses);
                                    adapter.notifyDataSetChanged();

                                    // Show message if no courses found
                                    if (courseList.isEmpty()) {
                                        Toast.makeText(this, "No courses found", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                    }
                }
            });
    }

    // Course Model
    public static class Course {
        private String courseId;
        private String courseName;
        private String instructor;
        private String semester;
        private String studentEmail;

        // Default constructor required for Firestore
        public Course() {}

        // Getters and Setters
        public String getCourseId() { return courseId; }
        public void setCourseId(String courseId) { this.courseId = courseId; }

        public String getCourseName() { return courseName; }
        public void setCourseName(String courseName) { this.courseName = courseName; }

        public String getInstructor() { return instructor; }
        public void setInstructor(String instructor) { this.instructor = instructor; }

        public String getSemester() { return semester; }
        public void setSemester(String semester) { this.semester = semester; }

        public String getStudentEmail() { return studentEmail; }
        public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }

        // Override equals and hashCode for duplicate prevention
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Course course = (Course) o;
            return courseId.equals(course.courseId);
        }

        @Override
        public int hashCode() {
            return courseId.hashCode();
        }
    }

    // RecyclerView Adapter for Buttons
    public class CourseButtonAdapter extends RecyclerView.Adapter<CourseButtonAdapter.CourseButtonViewHolder> {
        private List<Course> courseList;

        public CourseButtonAdapter(List<Course> courseList) {
            this.courseList = courseList;
        }

        @NonNull
        @Override
        public CourseButtonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_course_button_layout, parent, false);
            return new CourseButtonViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull CourseButtonViewHolder holder, int position) {
            Course course = courseList.get(position);
            
            // Set button text to course details
            String buttonText = String.format("%s - %s",
                course.getCourseId(), 
                course.getCourseName());
            
            holder.courseButton.setText(buttonText);
            
            // Set click listener
            holder.courseButton.setOnClickListener(v -> {
                // Example: Open a new activity for this course
                Intent intent = new Intent(CourseButtonActivity.this, NTAG215ReaderActivity.class);
                intent.putExtra("COURSE_ID", course.getCourseId());
                intent.putExtra("COURSE_NAME", course.getCourseName());
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return courseList.size();
        }

        // ViewHolder Class
        public class CourseButtonViewHolder extends RecyclerView.ViewHolder {
            Button courseButton;

            public CourseButtonViewHolder(@NonNull View itemView) {
                super(itemView);
                courseButton = itemView.findViewById(R.id.courseButton);
            }
        }
    }
}