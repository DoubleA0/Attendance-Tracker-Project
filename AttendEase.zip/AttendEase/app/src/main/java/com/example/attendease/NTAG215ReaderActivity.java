package com.example.attendease;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.nfc.tech.NfcA;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NTAG215ReaderActivity extends AppCompatActivity {
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] intentFiltersArray;
    private String[][] techListsArray;
    private TextView nfcDataTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc_reader);

        // Initialize UI
        nfcDataTextView = findViewById(R.id.nfcDataTextView);

        // Initialize NFC Adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        // Check if NFC is available
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Check if NFC is enabled
        if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC in your device settings", Toast.LENGTH_LONG).show();
        }

        // Create a pending intent for NFC foreground dispatch
        pendingIntent = PendingIntent.getActivity(
                this,
                0,
                new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_MUTABLE
        );

        // Setup intent filters for NFC
        IntentFilter nfcAIntent = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);

        intentFiltersArray = new IntentFilter[]{nfcAIntent};

        // Define the technologies we want to handle (specifically for NTAG215)
        techListsArray = new String[][]{
                new String[]{NfcA.class.getName()},
                new String[]{MifareUltralight.class.getName()}
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Enable foreground dispatch to intercept NFC intents
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(
                    this,
                    pendingIntent,
                    intentFiltersArray,
                    techListsArray
            );
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Disable foreground dispatch
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        // Check if the intent is a tech discovered intent
        if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

            if (tag != null) {
                // Try reading with MifareUltralight (used by NTAG215)
                MifareUltralight ultralight = MifareUltralight.get(tag);

                if (ultralight != null) {
                    try {
                        ultralight.connect();

                        // Read specific pages for NTAG215
                        String nfcData = readNTAG215Data(ultralight);

                        // Update UI
                        nfcDataTextView.setText("NTAG215 Data: " + nfcData);

                        // Process the data
                        NFCScanner.handleNfcDetected(intent);




                        ultralight.close();
                    } catch (IOException e) {
                        Toast.makeText(this, "Error reading NTAG215: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Not an NTAG215 tag", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private String readNTAG215Data(MifareUltralight ultralight) throws IOException {
        // NTAG215 has 135 pages, with first few pages containing system information
        // This example reads from a specific page (adjust based on your tag's content)
        StringBuilder dataBuilder = new StringBuilder();

        try {
            // Read multiple pages (adjust page numbers as needed)
            for (int page = 4; page < 10; page++) {
                byte[] pageData = ultralight.readPages(page);

                // Convert to readable string
                String pageString = new String(pageData, StandardCharsets.UTF_8).trim();
                dataBuilder.append(pageString);
            }

            return dataBuilder.toString();
        } catch (IOException e) {
            Toast.makeText(this, "Could not read NTAG215 pages", Toast.LENGTH_SHORT).show();
            return "Error reading NTAG215";
        }
    }

    private void processNFCData(String data) {
        try {
            // Validate and process the extracted data
            if (isValidNTAG215Data(data)) {
                // Extract student ID or other relevant information
                String studentId = extractStudentId(data);

                if (studentId != null) {
                    // Mark attendance or perform action
                    //markAttendance(studentId);
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error processing NFC data", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidNTAG215Data(String data) {
        // Implement validation specific to your NTAG215 tag format
        return data != null && !data.isEmpty() && data.length() > 5;
    }

    private String extractStudentId(String data) {
        // Implement logic to extract student ID from the NTAG215 data
        // This might involve parsing a specific format or using regex
        // Example: Assuming student ID is the first 8 digits
        String studentId = data.replaceAll("[^0-9]", "");
        return studentId.length() >= 8 ? studentId.substring(0, 8) : null;
    }

//    private void markAttendance(String studentId) {
//        // Implement attendance marking logic
//        // This could interact with your AttendanceManager
//        AttendanceManager.getInstance().markAttendance(
//                "CurrentCourse",
//                studentId,
//                "Student Name",
//                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()),
//                FirebaseAuth.getInstance().getCurrentUser()
//        );
//    }
}