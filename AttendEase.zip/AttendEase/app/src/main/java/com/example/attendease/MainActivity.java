package com.example.attendease;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcA;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.Firebase;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "NTAG215Reader";
    public static final String Error_Detected = "No NTAG215 NFC Tag Detected";
    public static final String Write_Success = "Text Written Successfully!";
    public static final String Write_Error = "Error During Writing, Try Again!";
    public static final byte[] NTAG215_VERSION = {0x00, 0x04, 0x04, 0x02, 0x01, 0x00, 0x13, 0x03};

    String usernameInput;
    String passwordInput;

    NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    IntentFilter[] writingTagFilters;
    boolean writeMode;
    Tag myTag;
    Context context;
    TextView edit_query;
    TextView nfc_contents;
    Button ActivateButton;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(androidx.appcompat.R.style.Base_Theme_AppCompat);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        edit_query = findViewById(R.id.edit_query);
        nfc_contents = findViewById(R.id.nfc_contents);
        ActivateButton = findViewById(R.id.ActivateButton);
        context = this;

//        com.google.firebase.storage.FirebaseStorage.getInstance();





        ActivateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (myTag == null) {
                        Toast.makeText(context, Error_Detected, Toast.LENGTH_LONG).show();
                    } else if (!isNTAG215(myTag)) {
                        Toast.makeText(context, "Not an NTAG215 card", Toast.LENGTH_LONG).show();
                    } else {
                        write("PlainText|" + edit_query.getText().toString(), myTag);
                        Toast.makeText(context, Write_Success, Toast.LENGTH_LONG).show();
                    }
                } catch (IOException e) {
                    Toast.makeText(context, Write_Error, Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                } catch (FormatException e) {
                    Toast.makeText(context, Write_Error, Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "This device does not support NFC", Toast.LENGTH_SHORT).show();
            finish();
        }

        readFromIntent(getIntent());
        pendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE);

        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
        writingTagFilters = new IntentFilter[]{tagDetected};
    }

    private boolean isNTAG215(Tag tag) {
        NfcA nfcA = NfcA.get(tag);
        if (nfcA == null) return false;

        try {
            nfcA.connect();
            // NTAG215 has 540 bytes of user memory (135 pages * 4 bytes)
            if (nfcA.getMaxTransceiveLength() < 540) {
                return false;
            }

            // Get version command for NTAG215
            byte[] command = {(byte) 0x60};  // GET_VERSION command
            byte[] response = nfcA.transceive(command);

            // Check if response matches NTAG215 version info
            return Arrays.equals(response, NTAG215_VERSION);
        } catch (IOException e) {
            Log.e(TAG, "Error checking for NTAG215: " + e.getMessage());
            return false;
        } finally {
            try {
                nfcA.close();
            } catch (IOException e) {
                Log.e(TAG, "Error closing NFC connection: " + e.getMessage());
            }
        }
    }

    private void readFromIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {

            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            if (tag != null && isNTAG215(tag)) {
                Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
                NdefMessage[] msgs = null;
                if (rawMsgs != null) {
                    msgs = new NdefMessage[rawMsgs.length];
                    for (int i = 0; i < rawMsgs.length; i++) {
                        msgs[i] = (NdefMessage) rawMsgs[i];
                    }
                    buildTagViews(msgs);
                } else {
                    // Try to read raw data if NDEF is not available
                    readRawNTAG215Data(tag);
                }
            } else {
                Toast.makeText(this, "Not an NTAG215 card", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void readRawNTAG215Data(Tag tag) {
        NfcA nfcA = NfcA.get(tag);
        try {
            nfcA.connect();
            StringBuilder data = new StringBuilder();

            // Read first 135 pages (540 bytes) of NTAG215
            for (int page = 0; page < 135; page++) {
                byte[] cmd = {
                        (byte) 0x30,  // READ command
                        (byte) page   // page address
                };
                byte[] response = nfcA.transceive(cmd);
                data.append(bytesToHex(response)).append(" ");
            }

            nfc_contents.setText("Raw NTAG215 Data: " + data.toString());
        } catch (IOException e) {
            Log.e(TAG, "Error reading raw data: " + e.getMessage());
            Toast.makeText(this, "Error reading raw data", Toast.LENGTH_SHORT).show();
        } finally {
            try {
                nfcA.close();
            } catch (IOException e) {
                Log.e(TAG, "Error closing NFC connection: " + e.getMessage());
            }
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) {
            hex.append(String.format("%02X", b));
        }
        return hex.toString();
    }

    private void buildTagViews(NdefMessage[] msgs) {
        if (msgs == null || msgs.length == 0) return;

        String text = "";
        byte[] payload = msgs[0].getRecords()[0].getPayload();
        String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16";
        int languageCodeLength = payload[0] & 0063;

        try {
            text = new String(payload, languageCodeLength + 1,
                    payload.length - languageCodeLength - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "UnsupportedEncoding: " + e.toString());
        }

        nfc_contents.setText(text);
    }

    private void write(String text, Tag tag) throws IOException, FormatException {
        if (!isNTAG215(tag)) {
            throw new IOException("Not an NTAG215 tag");
        }

        NdefRecord[] records = { createRecord(text) };
        NdefMessage message = new NdefMessage(records);
        Ndef ndef = Ndef.get(tag);

        if (ndef == null) {
            throw new FormatException("Tag is not NDEF formatted");
        }

        if (!ndef.isWritable()) {
            throw new IOException("Tag is read-only");
        }

        int size = message.getByteArrayLength();
        if (ndef.getMaxSize() < size) {
            throw new IOException("Tag capacity is " + ndef.getMaxSize() + " bytes, message is " + size + " bytes.");
        }

        try {
            ndef.connect();
            ndef.writeNdefMessage(message);
        } finally {
            ndef.close();
        }
    }

    private NdefRecord createRecord(String text) throws UnsupportedEncodingException {
        String lang = "en";
        byte[] textBytes = text.getBytes();
        byte[] langBytes = lang.getBytes();
        int langLength = langBytes.length;
        int textLength = textBytes.length;
        byte[] payload = new byte[1 + langLength + textLength];

        payload[0] = (byte) langLength;
        System.arraycopy(langBytes, 0, payload, 1, langLength);
        System.arraycopy(textBytes, 0, payload, 1 + langLength, textLength);

        return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT,
                new byte[0], payload);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readFromIntent(intent);
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            myTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        writeModeOff();
    }

    @Override
    public void onResume() {
        super.onResume();
        writeModeOn();
    }

    private void writeModeOn() {
        writeMode = true;
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, writingTagFilters, null);
    }

    private void writeModeOff() {
        writeMode = false;
        nfcAdapter.disableForegroundDispatch(this);
    }
}