package com.example.attendease;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class NFCScanner extends ViewModel {
    private static NfcAdapter nfcAdapter;
    private static String selectedCourse;
    private static String currentUser;
    private static String userId;
    private static String userName;
    private MutableLiveData<NFCCardData> lastScannedCardData = new MutableLiveData<>();
    private static MutableLiveData<String> scanError = new MutableLiveData<>();
    private static FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static FirebaseAuth mAuth = FirebaseAuth.getInstance();

    public LiveData<NFCCardData> getLastScannedCardData() {
        return lastScannedCardData;
    }

    public LiveData<String> getScanError() {
        return scanError;
    }

    public static void beginScanning(String courseId, String user) {
        if (nfcAdapter == null || !nfcAdapter.isEnabled()) {
            scanError.setValue("NFC is not supported on this device");
            return;
        }

        selectedCourse = courseId;
        currentUser = user;
        System.out.println("Selected course ID for scanning: " + courseId);
    }

    public static void handleNfcDetected(Intent intent) {
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        Ndef ndef = Ndef.get(tag);
        if (ndef == null) {
            handleScanError("No NDEF messages found on card");
            return;
        }

        NdefMessage ndefMessage = ndef.getCachedNdefMessage();
        if (ndefMessage == null) {
            handleScanError("No valid records found on card");
            return;
        }

        NdefRecord[] records = ndefMessage.getRecords();
        if (records.length > 0) {
            byte[] payload = records[0].getPayload();
            String payloadString = new String(payload, StandardCharsets.UTF_8);
            System.out.println("Payload string: " + payloadString);
            processNTAG215Data(payloadString);
        } else {
            handleScanError("Unable to decode card data");
        }
    }

    public static void processNTAG215Data(String payload) {
        List<String> components = Arrays.asList(payload.split("\\|"));
        System.out.println("Processing components: " + components);

        if (components.size() < 2) {
            handleScanError("Invalid card format");
            return;
        }

        String scannedCourseId = components.get(0).replace("en", "").trim();
        String professorId = components.get(1).trim();

        System.out.println("Extracted courseId: " + scannedCourseId);
        System.out.println("Extracted professorId: " + professorId);


        validateProfessorCard(scannedCourseId, professorId);
    }

    //        System.out.println("Selected course: " + selectedCourse);
//
//        if (!scannedCourseId.equals(selectedCourse)) {
//            handleScanError("This card is not for the selected course. Scanned: " + scannedCourseId + ", Selected: " + selectedCourse);
//            return;
//        }

    private static void validateProfessorCard(String courseId, String professorId) {

        String studentId;
        String studentName;

        FirebaseUser currentFirebaseUser = mAuth.getCurrentUser();
        if (currentFirebaseUser == null) {
            handleScanError("User not authenticated");
            return;
        }

        db.collection("Students")
                .whereEqualTo("studentEmail", currentFirebaseUser.getEmail())
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            // studentId is stored as a field in the document
                            userId = querySnapshot.getDocuments().get(0).getString("studentId");
                        } else {
                            handleScanError("No student found with this email");
                        }
                    } else {
                        task.getException();
                        handleScanError(task.getException().getMessage());
                    }
                });

        db.collection("Students")
                .whereEqualTo("studentEmail", currentFirebaseUser.getEmail())
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            // studentId is stored as a field in the document
                            userName = querySnapshot.getDocuments().get(0).getString("studentName");
                        } else {
                            handleScanError("No student found with this name");
                        }
                    } else {
                        task.getException();
                        handleScanError(task.getException().getMessage());
                    }
                });


        db.collection("Professor")
                .whereEqualTo("courseId", courseId)
                .whereEqualTo("professorId", professorId)
                .get()
                .addOnCompleteListener(professorTask -> {
                    if (professorTask.isSuccessful()) {
                        QuerySnapshot professorSnapshot = professorTask.getResult();
                        if (professorSnapshot != null && !professorSnapshot.isEmpty()) {
                            // Professor card is valid, now get professor details
                            String professorName = professorSnapshot.getDocuments().get(0).getString("professorName");

                            // Prepare attendance record
                            Map<String, Object> attendanceRecord = new HashMap<>();
                            attendanceRecord.put("courseId", courseId);
                            attendanceRecord.put("professorId", professorId);
                            attendanceRecord.put("professorName", professorName);
                            attendanceRecord.put("studentEmail", currentFirebaseUser.getEmail());
                            attendanceRecord.put("studentId", userId);
                            attendanceRecord.put("studentName", userName);
                            attendanceRecord.put("timestamp", Timestamp.now());

                            // Add attendance record to Firestore
                            db.collection("Attendance")
                                    .add(attendanceRecord)
                                    .addOnSuccessListener(documentReference -> {
                                        // Attendance record added successfully
                                        System.out.println("Attendance record added for student: " + currentFirebaseUser.getEmail());
                                        scanError.setValue("Attendance recorded successfully");
                                    })
                                    .addOnFailureListener(e -> {
                                        handleScanError("Failed to record attendance: " + e.getLocalizedMessage());
                                    });
                        } else {
                            handleScanError("Invalid professor card for this course");
                        }
                    } else {
                        handleScanError("Database error: " + Objects.requireNonNull(professorTask.getException()).getLocalizedMessage());
                    }
                });
    }

    private static void handleScanError(String errorMessage) {
        scanError.setValue(errorMessage);
    }

    private void retrieveStudentId(String studentEmail, OnStudentIdRetrievedListener listener) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("Students")
                .whereEqualTo("studentEmail", studentEmail)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            // Assuming studentId is stored as a field in the document
                            String studentId = querySnapshot.getDocuments().get(0).getString("studentId");

//                            if (studentId != null) {
//                                listener.onStudentIdRetrieved(studentId);
//                            } else {
//                                handleScanError("Student ID not found");
//                            }
                        } else {
                            handleScanError("No student found with this email");
                        }
                    } else {
                        task.getException();
                        handleScanError(task.getException().getMessage());
                    }
                });
    }

    // Interface to handle the asynchronous result
    public interface OnStudentIdRetrievedListener {
        void onStudentIdRetrieved(String studentId);
        void onError(String errorMessage);
    }
}

