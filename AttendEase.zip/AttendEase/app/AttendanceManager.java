public class AttendanceManager {

